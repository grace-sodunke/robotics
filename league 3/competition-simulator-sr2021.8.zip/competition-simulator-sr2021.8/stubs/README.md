# Stubs

The stub files here serve two purposes:

- acting as just enough importable code that test discovery works despite the
  lack of a real Webots on CI

- type stubs for `mypy`
